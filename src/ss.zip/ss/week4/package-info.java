/**
 * Info about this package doing something for package-info.java file.
 * @author Gracjan
 * @version 1.0
 */
package ss.week4;