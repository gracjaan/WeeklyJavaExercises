package ss.week3.hotel;

public class Playground {
    public static void main(String[] args) {
        System.out.println(String.format("%s                       %.2f", "Item 1", 20.0));
    }
}
