package ss.week5;

public class WrongArgumentException extends Exception{
}
