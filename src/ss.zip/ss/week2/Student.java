package ss.week2;

/**
 * Student class, which will contain a method <b>passed</b> 
 * which will return whether a student has passed or not. 
 * @author Wim Kamerman
 */
public class Student {
	
	private static final int CRITERION = 70;
	private int score;
	
	public boolean passed () {
	   return this.score>=70;
	}
	
}
