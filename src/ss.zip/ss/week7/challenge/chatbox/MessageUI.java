package ss.week7.challenge.chatbox;

/**
 * P2 prac wk4.
 * MessageUI. 
 * @author  Theo Ruys
 * @version 2005.02.21
 */
interface MessageUI {
	public void addMessage(String msg);
}
