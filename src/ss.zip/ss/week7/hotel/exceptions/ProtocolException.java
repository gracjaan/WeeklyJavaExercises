package ss.week7.hotel.exceptions;

public class ProtocolException extends Exception {

	private static final long serialVersionUID = 5574774762493692470L;

	public ProtocolException(String msg) {
		super(msg);
	}

}
